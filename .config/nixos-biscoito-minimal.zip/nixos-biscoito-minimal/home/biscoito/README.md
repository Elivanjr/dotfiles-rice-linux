Espaço reservado para os dotfiles. Home Manager foi deixado de fora desta versão mínima.
