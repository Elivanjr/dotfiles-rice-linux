Espaço reservado para scripts pessoais.
