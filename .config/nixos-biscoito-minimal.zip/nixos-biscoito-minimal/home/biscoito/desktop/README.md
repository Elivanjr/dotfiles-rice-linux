Coloque aqui as configurações de Hyprland e Quickshell, preservando as subpastas.
