Espaço reservado para configurações de programas do usuário.
