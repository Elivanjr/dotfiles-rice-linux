O arquivo hardware-configuration.nix será gerado no ambiente Live e deve ser colocado nesta pasta, além de adicionado aos imports do host.
