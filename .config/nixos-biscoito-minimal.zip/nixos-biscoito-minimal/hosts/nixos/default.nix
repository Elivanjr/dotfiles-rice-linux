{ ... }:
{
  imports = [
    ../../modules/system/boot.nix
    ../../modules/system/locale.nix
    ../../modules/system/networking.nix
    ../../modules/system/users.nix
    ../../modules/desktop/hyprland.nix
    ../../modules/desktop/polkit.nix
    ../../modules/services/audio.nix
    ../../packages
  ];

  system.stateVersion = "26.05";
}
