# NixOS — Biscoito Edition (minimal)

Base modular e enxuta para testar a instalação do NixOS em uma VM.

## Incluído
- NixOS Flake `x86_64-linux`, canal `nixos-26.05`.
- Hyprland e Kitty.
- Polkit, NetworkManager e PipeWire.
- Usuário `biscoito` nos grupos `wheel` e `networkmanager`.
- Localidade `pt_BR.UTF-8`, fuso `America/Sao_Paulo` e teclado de console `br-abnt2`.
- Git, curl, wget, vim e fastfetch.

## Removido nesta versão mínima
Ollama, Bluetooth, impressão, Brave, Discord, Spotify, Neovim, Zsh, Quickshell e Home Manager. Podem ser adicionados depois em módulos separados. Os diretórios `home/biscoito/` ficam como espaço reservado para os dotfiles.

## Antes de instalar
1. Inicialize a VM em UEFI (o módulo usa systemd-boot).
2. Recomendo aumentar o disco virtual para 40–60 GB.
3. Particione e monte o disco manualmente.
4. Gere a configuração de hardware com `nixos-generate-config`.
5. Coloque `hardware-configuration.nix` em `hosts/nixos/` e adicione `./hardware-configuration.nix` ao `imports` de `hosts/nixos/default.nix`.
6. Revise o disco de destino antes de qualquer operação de particionamento/formatação.

Para instalar, na raiz do repositório:

```bash
sudo nixos-install --flake .#nixos
```

Para avaliar a configuração:

```bash
nix flake check
```

## Observações
- `system.stateVersion = "26.05"` foi preservado da configuração original.
- O usuário `biscoito` é criado sem senha declarada; defina uma durante a instalação ou após o primeiro boot com `passwd biscoito`.
- Não inclui script de particionamento automático.
- Hyprland está habilitado, mas não inclui gerenciador de login nem dotfiles pessoais. A configuração da sessão pode ser integrada depois.
