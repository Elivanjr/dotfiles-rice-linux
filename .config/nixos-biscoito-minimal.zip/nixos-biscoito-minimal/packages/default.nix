{ pkgs, ... }:
{
  environment.systemPackages = with pkgs; [
    kitty
    git
    curl
    wget
    vim
    fastfetch
  ];
}
