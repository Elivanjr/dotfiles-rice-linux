{ ... }:
{
  security.polkit.enable = true;
}
